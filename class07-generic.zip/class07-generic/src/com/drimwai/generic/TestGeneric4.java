package com.drimwai.generic;

public class TestGeneric4 {
    public static void main(String[] args) {
        SumTools<Integer> s = new SumTools<Integer>(1,2);
        Integer sum = s.getSum();
        System.out.println(sum);

//		SumTools<String> s = new SumTools<String>("1","2");//错误，因为String类型不是extends Number
    }
}
