package com.drimwai.generic;

import java.util.Arrays;

public class TestGeneric3 {
    public static void main(String[] args) {
        int[] arr = {3,2,5,1,4};
        //MyArrays.sort(arr);//错误的，因为int[]不是对象数组

        String[] strings = {"hello","java","chai"};
        MyArrays.sort(strings);
        System.out.println(Arrays.toString(strings));

        Integer[] integers = {3,2,5,1,4};
        MyArrays.sort(integers);
        System.out.println(Arrays.toString(integers));
    }
}
