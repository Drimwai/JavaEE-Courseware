package com.drimwai.generic;

public class TestGeneric2 {
    public static void main(String[] args) {
        //语文老师使用时：
        Student<String> stu1 = new Student<String>("张三", "良好");
        System.out.println(stu1.toString());
        //数学老师使用时：
        //Student<double> stu2 = new Student<double>("张三", 90.5);//错误，必须是引用数据类型
        Student<Double> stu2 = new Student<Double>("张三", 90.5);
        System.out.println(stu2.toString());
        //英语老师使用时：
        Student<Character> stu3 = new Student<Character>("张三", 'C');
        System.out.println(stu3.toString());
        //错误的指定
        //Student<Object> stu = new Student<String>();//错误的

    }
}
