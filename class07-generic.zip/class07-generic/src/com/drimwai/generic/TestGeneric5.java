package com.drimwai.generic;

public class TestGeneric5 {
    public static void main(String[] args) {
        // 语文老师使用时：
        Student<String> stu1 = new Student<String>("张三", "良好");
        // 数学老师使用时：
        // Student<double> stu2 = new Student<double>("张三", 90.5);//错误，必须是引用数据类型
        Student<Double> stu2 = new Student<Double>("张三", 90.5);
        // 英语老师使用时：
        Student<Character> stu3 = new Student<Character>("张三", 'C');
        //通配符的使用
        Student<?>[] arr = new Student[3];
        arr[0] = stu1;
        arr[1] = stu2;
        arr[2] = stu3;
        StudentService.print(arr);
    }
}
