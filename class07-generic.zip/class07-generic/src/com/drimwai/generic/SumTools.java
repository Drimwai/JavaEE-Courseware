package com.drimwai.generic;

import java.math.BigDecimal;
import java.math.BigInteger;

public class SumTools<T extends Number & Comparable<T>> {
    private T a;
    private T b;
    public SumTools(T a, T b) {
        super();
        this.a = a;
        this.b = b;
    }
    @SuppressWarnings("unchecked")
    public T getSum(){
        if(a instanceof BigInteger){
            return (T)((BigInteger) a).add((BigInteger)b);
        }else if(a instanceof BigDecimal){
            return (T)((BigDecimal) a).add((BigDecimal)b);
        }else if(a instanceof Short){
            return (T)(Integer.valueOf((Short)a+(Short)b));
        }else if(a instanceof Integer){
            return (T)(Integer.valueOf((Integer)a+(Integer)b));
        }else if(a instanceof Long){
            return (T)(Long.valueOf((Long)a+(Long)b));
        }else if(a instanceof Float){
            return (T)(Float.valueOf((Float)a+(Float)b));
        }else if(a instanceof Double){
            return (T)(Double.valueOf((Double)a+(Double)b));
        }
        throw new UnsupportedOperationException("不支持该操作");
    }

}
