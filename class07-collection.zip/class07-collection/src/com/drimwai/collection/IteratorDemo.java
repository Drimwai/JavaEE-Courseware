package com.drimwai.collection;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class IteratorDemo {
    public static void main(String[] args) {
        // 使用多态方式 创建对象
        Collection<String> coll = new ArrayList<String>();
        // 添加元素到集合
        coll.add("串串星人");
        coll.add("吐槽星人");
        coll.add("汪星人");
        //遍历
        //使用迭代器遍历,每个集合对象都有自己的迭代器
        Iterator<String> it = coll.iterator();
        //判断是否有迭代元素
        while(it.hasNext()){
            String s = it.next();//获取迭代出的元素
            System.out.println(s);
        }
    }

    @Test
    public void test02(){
        Collection<Integer> coll = new ArrayList<>();
        coll.add(1);
        coll.add(2);
        coll.add(3);
        coll.add(4);
        //使用迭代器进行遍历
        Iterator<Integer> iterator = coll.iterator();
        while(iterator.hasNext()){
            Integer element = iterator.next();
            if(element%2 == 0){
//				coll.remove(element);//错误的
                iterator.remove();
            }
        }
        System.out.println(coll);
    }
}
